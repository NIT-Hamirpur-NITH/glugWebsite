<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Bootstrap extends Theme
{
    // Boostrap plugin will look for this class var to know it should load
    public $load_bootstrapper_plugin = true;

}
